
let eyeX = 0;
let eyeSpeed;

let handY = 0;
let handSpeed;

let noseX = 0;
let noseY = 0;
let noseSpeedX;
let noseSpeedY;

let titleSize = 22;
let titleCount = 0;
let titleDirection = 1;

function setup() {
  createCanvas(300, 500);

  // Random speeds for each shape
  eyeSpeed = random(0.5, 1.5);
  handSpeed = random(0.5, 1.5);
  noseSpeedX = random(0.5, 1.5);
  noseSpeedY = random(0.5, 1.5);

  frameRate(30);
}

function draw() {
  background(173, 216, 230);

  // Title grows 5 times, then shrinks 5 times
  if (frameCount % 10 == 0) {
    titleSize += titleDirection * 2;
    titleCount++;

    if (titleCount == 5) {
      titleDirection *= -1;
      titleCount = 0;
    }
  }

  fill(0);
  noStroke();
  textSize(titleSize);
  textAlign(CENTER);
  text("It's Me!", 150, 35);

  fill(100, 200, 100);
  rect(0, 400, 300, 100);

  fill(255, 230, 180);
  stroke(0);
  strokeWeight(3);
  ellipse(150, 150, 80, 80);

  eyeX += eyeSpeed;

  if (eyeX > 5 || eyeX < -5) {
    eyeSpeed *= -1;
  }

  stroke(50, 160, 150);
  strokeWeight(8);
  point(135 + eyeX, 145);
  point(165 + eyeX, 145);

  stroke(0);
  noFill();
  strokeWeight(3);
  arc(150, 160, 35, 25, 0, PI);

  noseX += noseSpeedX;
  noseY += noseSpeedY;

  if (noseX > 5 || noseX < -5) {
    noseSpeedX *= -1;
  }

  if (noseY > 5 || noseY < -5) {
    noseSpeedY *= -1;
  }

  fill(255, 180, 130);
  stroke(0);
  strokeWeight(1);
  triangle(
    150 + noseX, 148 + noseY,
    144 + noseX, 157 + noseY,
    156 + noseX, 157 + noseY
  );

  fill(255, 0, 0);
  stroke(0);
  strokeWeight(2);
  rect(130, 190, 40, 100);

  strokeWeight(5);
  line(130, 205, 95, 285);
  line(170, 205, 205, 285);

  handY += handSpeed;

  if (handY > 10 || handY < -10) {
    handSpeed *= -1;
  }

  fill(255, 230, 180);
  strokeWeight(2);
  circle(95, 285 + handY, 12);
  circle(205, 285 + handY, 12);

  stroke(0);
  strokeWeight(5);
  line(140, 290, 110, 380);
  line(160, 290, 190, 380);

  fill(50);
  strokeWeight(2);
  rect(95, 375, 30, 12);
  rect(175, 375, 30, 12);

  fill(255);
  stroke(0);
  strokeWeight(2);
  rect(155, 450, 140, 40);

  // Name
  noStroke();
  fill(0);
  textSize(14);
  textAlign(CENTER);
  text("Quaid Callison", 225, 475);
}
