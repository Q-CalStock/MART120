
function setup() {
  createCanvas(300, 500);
  noLoop();
}

function draw() {
  background(173, 216, 230);

  // Title
  fill(0);
  noStroke();
  textSize(22);
  textAlign(CENTER);
  text("It's Me!", 150, 35);

  fill(100, 200, 100);
  rect(0, 400, 300, 100);

  fill(255, 230, 180);
  stroke(0);
  strokeWeight(3);
  ellipse(150, 150, 80, 80);

  stroke(0);
  strokeWeight(8);
  point(135, 145);
  point(165, 145);

  stroke(0);
  noFill();
  strokeWeight(3);
  arc(150, 160, 35, 25, 0, PI);

  fill(255, 180, 130);
  strokeWeight(1);
  triangle(150, 148, 144, 157, 156, 157);

  fill(255, 0, 0);
  stroke(0);
  strokeWeight(2);
  rect(130, 190, 40, 100);

  strokeWeight(5);
  line(130, 205, 95, 285);

  line(170, 205, 205, 285);

  fill(255, 230, 180);
  strokeWeight(2);
  circle(95, 285, 12);
  circle(205, 285, 12);

  stroke(0);
  strokeWeight(5);
  line(140, 290, 110, 380);
  line(160, 290, 190, 380);

  fill(50);
  strokeWeight(2);
  rect(95, 375, 30, 12);
  rect(175, 375, 30, 12);

  // Name box
  fill(255);
  stroke(0);
  strokeWeight(2);
  rect(155, 450, 140, 40);

  // Name
  noStroke();
  fill(0);
  textSize(14);
  textAlign(CENTER);
  text("Quaid Callison", 225, 475);
}
